package com.sahani.tubedownloader;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;

import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatDelegate;
import android.util.Log;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;

import at.huber.youtubeExtractor.YouTubeUriExtractor;
import at.huber.youtubeExtractor.YtFile;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    String youTubeURL = null;
    String WritePermission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
    String ReadPermission  = Manifest.permission.READ_EXTERNAL_STORAGE;
    private SharedPref sharedpref;

    Button signOutButton;
    ProgressBar progressBar;
    LinearLayout linearLayoutupgradebox, linearLayoutsignoutbox;
    TextView textViewusername;
    ProgressDialog pd;

    LinearLayout adContainer,adContainer2;
    public InterstitialAd interstitialAd;
    public AdView adView,adView2;
    public final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onStart() {
        super.onStart();
//        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        sharedpref = new SharedPref(this);
        if(sharedpref.loadNightModeState()) {
            setTheme(R.style.darktheme);
        }
        super.onCreate(savedInstanceState);
        AudienceNetworkAds.initialize(this);
        setContentView(R.layout.activity_main);

//        Intent intent = new Intent(MainActivity.this, UpdateService.class);
//        startService(intent);

        // Find the Ad Container
        //adContainer2 = (LinearLayout) findViewById(R.id.banner_container2);

        editText = findViewById(R.id.youtubevideourlenter);
        editText.requestFocus();

//        Bundle extras = getIntent().getExtras();
//        String value;
//        if (extras != null) {
//            value = extras.getString(Intent.EXTRA_TEXT);
//            Toast.makeText(this, ""+value, Toast.LENGTH_SHORT).show();
//            editText.setText(value);
//        }
        //Toast.makeText(this, ""+value1, Toast.LENGTH_SHORT).show();

        textViewusername = findViewById(R.id.username);
        linearLayoutupgradebox =findViewById(R.id.upgradebox);
        linearLayoutsignoutbox = findViewById(R.id.signoutbox);
        //signInButton = findViewById(R.id.sign_in_button);
        signOutButton = findViewById(R.id.sign_out_button);
        progressBar = findViewById(R.id.progressBar);


        if (ActivityCompat.checkSelfPermission(this, WritePermission) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, ReadPermission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{WritePermission, ReadPermission}, 1);
        }

        //==========================================
        interstitialAd = new InterstitialAd(this, "273219643930417_273221320596916");
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
                // Interstitial ad displayed callback
                Log.e(TAG, "Interstitial ad displayed.");
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                // Interstitial dismissed callback
                Log.e(TAG, "Interstitial ad dismissed.");
                adView.destroy();
                showAds2();
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                // Ad error callback
                Log.e(TAG, "Interstitial ad failed to load: " + adError.getErrorMessage());
            }

            @Override
            public void onAdLoaded(Ad ad) {
                // Interstitial ad is loaded and ready to be displayed
                Log.d(TAG, "Interstitial ad is loaded and ready to be displayed!");
                // Show the ad
                interstitialAd.show();
            }

            @Override
            public void onAdClicked(Ad ad) {
                // Ad clicked callback
                Log.d(TAG, "Interstitial ad clicked!");
            }

            @Override
            public void onLoggingImpression(Ad ad) {
                // Ad impression logged callback
                Log.d(TAG, "Interstitial ad impression logged!");
            }
        });

        showAds();
        isInternetWorking();
    }

    @Override
    public void onResume(){
        super.onResume();
        Bundle extras = getIntent().getExtras();
        String value;
        if (extras != null) {
            value = extras.getString(Intent.EXTRA_TEXT);
            //Toast.makeText(this, ""+value, Toast.LENGTH_SHORT).show();
            editText.setText(value);
        }
    }

    public void isInternetWorking() {
        ConnectivityManager manager =(ConnectivityManager) getApplicationContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = null;
        if (manager != null) {
            activeNetwork = manager.getActiveNetworkInfo();
        }
        if (null != activeNetwork) {
            if(activeNetwork.getType() == ConnectivityManager.TYPE_WIFI){
                //we have WIFI
                editText.setEnabled(true);
            }
            if(activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE){
                //we have cellular data
                editText.setEnabled(true);
            }
        } else{
            //we have no connection :(
            editText.setEnabled(false);
            Toast.makeText(this, "No active Internet Connection was found!", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
        finishAffinity();
        System.exit(0);
    }

    public void openFolder()
    {
        startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));

    }

    public void YouTubeVideoDownloadF(int iTag){

        if (ActivityCompat.checkSelfPermission(this, WritePermission) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, ReadPermission) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{WritePermission, ReadPermission}, 1);
        } else {

            YTDownload(iTag);
        }
    }

    public void YTDownload(final int itag) {
        String VideoURLDownload = youTubeURL;
        @SuppressLint("StaticFieldLeak") YouTubeUriExtractor youTubeUriExtractor = new YouTubeUriExtractor(this) {
            @Override
            public void onUrisAvailable(String videoId, final String videoTitle, SparseArray<YtFile> ytFiles) {
                if ((ytFiles != null)) {
                    String downloadURL = ytFiles.get(itag).getUrl();
                    Log.e("Download URL: ", downloadURL);
                    if(itag==18 || itag == 22) {
                        String mp4=".mp4";
                        DownloadManagingF(downloadURL, videoTitle,mp4);
                    }else if (itag == 251){
                        String mp3=".mp3";
                        DownloadManagingF(downloadURL,videoTitle,mp3);
                    }

                } else Toast.makeText(MainActivity.this, "Error With URL", Toast.LENGTH_LONG).show();
            }
        };
        youTubeUriExtractor.execute(VideoURLDownload);
    }

    public void DownloadManagingF(String downloadURL, String videoTitle,String extentiondwn){
        pd = new ProgressDialog(MainActivity.this);
        if (downloadURL != null) {
            DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadURL));
            request.setTitle(videoTitle);
            request.setDestinationInExternalPublicDir("/Download/Tube-Media-Downloader/", videoTitle + extentiondwn);
            if (downloadManager != null) {
                //Toast.makeText(getApplicationContext(),"Downloading...",Toast.LENGTH_SHORT).show();
                downloadManager.enqueue(request);
                pd.setMessage("Downloading media please wait..");
                pd.setCancelable(false);
                pd.show();
            }
            BroadcastReceiver onComplete = new BroadcastReceiver() {
                public void onReceive(Context ctxt, Intent intent) {
                    Toast.makeText(getApplicationContext(),"Download Completed!",Toast.LENGTH_SHORT).show();
                    pd.dismiss();
//                    AdSettings.addTestDevice("1d7cd2c2-fd6d-4bf9-9803-17be46be6c08");
                    interstitialAd.loadAd();
                    Uri selectedUri = Uri.parse(Environment.getExternalStorageDirectory() + "/Download/Tube-Media-Downloader/");
                    Intent intentop = new Intent(Intent.ACTION_VIEW);
                    intentop.setDataAndType(selectedUri, "resource/folder");

                    if (intentop.resolveActivityInfo(getPackageManager(), 0) != null)
                    {
                        startActivity(intentop);
                    }
                    else
                    {
                        //Toast.makeText(getApplicationContext(),"Saved on: Download/Tube-Media-Downloader",Toast.LENGTH_LONG).show();
                        //restartApp();
                    }
                    unregisterReceiver(this);
//                    finish();
                    editText.setText("");
                }
            };
            registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        }
    }

    public void viewdownloadsbtn(View view) {
        openFolder();
    }

    public void ytvdownload(View view) {
        youTubeURL = editText.getText().toString();
        if (youTubeURL.contains("http")) {
            YouTubeVideoDownloadF(18);
        }
        else Toast.makeText(this,"Please enter a valid URL first",Toast.LENGTH_LONG).show();
    }

    public void ytvdownloadhdp(View view) {
        youTubeURL = editText.getText().toString();
        if (youTubeURL.contains("http")) {

            YouTubeVideoDownloadF(140);
        }
        else Toast.makeText(this,"Please enter a valid URL first",Toast.LENGTH_LONG).show();
    }

    public void ytvdownloadaudio(View view) {
        youTubeURL = editText.getText().toString();
        if (youTubeURL.contains("http"))
            YouTubeVideoDownloadF(251);
        else Toast.makeText(this,"Please enter a valid URL first",Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.day:
                sharedpref.setNightModeState(false);
                restartApp();
                return(true);
            case R.id.night:
                sharedpref.setNightModeState(true);
                restartApp();
                return(true);
        }
        return(super.onOptionsItemSelected(item));
    }

    public void restartApp() {
        Intent i = new Intent(getApplicationContext(),MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    public void showAds(){
        // Find the Ad Container
        adContainer = (LinearLayout) findViewById(R.id.banner_container);
//        AdSettings.addTestDevice("1d7cd2c2-fd6d-4bf9-9803-17be46be6c08");
        adView = new AdView(this, "273219643930417_273220177263697", AdSize.BANNER_HEIGHT_50);

        // Add the ad view to your activity layout
        adContainer.addView(adView);

        // Request an ad
        adView.loadAd();
    }
    public void showAds2(){
        // Find the Ad Container
        adContainer = (LinearLayout) findViewById(R.id.banner_container);
//        AdSettings.addTestDevice("1d7cd2c2-fd6d-4bf9-9803-17be46be6c08");
        adView = new AdView(this, "273219643930417_273220177263697", AdSize.BANNER_HEIGHT_50);

        // Add the ad view to your activity layout
        adContainer.addView(adView);

        // Request an ad
        adView.loadAd();
    }

}
